class IndexController < ApplicationController
  def index
  end
  def app
  end
end
